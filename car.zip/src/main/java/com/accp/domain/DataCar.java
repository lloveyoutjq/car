package com.accp.domain;

public class DataCar {
    private Integer id;

    private String cartypename;

    private Integer engineid;

    private Float price;

    private Float caryearprice;

    private String power;

    private String importordomestic;

    private String fuellabel;

    private String load;

    private Integer carbrandid;

    private String img;

    private String default1;

    private String default2;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCartypename() {
        return cartypename;
    }

    public void setCartypename(String cartypename) {
        this.cartypename = cartypename;
    }

    public Integer getEngineid() {
        return engineid;
    }

    public void setEngineid(Integer engineid) {
        this.engineid = engineid;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Float getCaryearprice() {
        return caryearprice;
    }

    public void setCaryearprice(Float caryearprice) {
        this.caryearprice = caryearprice;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getImportordomestic() {
        return importordomestic;
    }

    public void setImportordomestic(String importordomestic) {
        this.importordomestic = importordomestic;
    }

    public String getFuellabel() {
        return fuellabel;
    }

    public void setFuellabel(String fuellabel) {
        this.fuellabel = fuellabel;
    }

    public String getLoad() {
        return load;
    }

    public void setLoad(String load) {
        this.load = load;
    }

    public Integer getCarbrandid() {
        return carbrandid;
    }

    public void setCarbrandid(Integer carbrandid) {
        this.carbrandid = carbrandid;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getDefault1() {
        return default1;
    }

    public void setDefault1(String default1) {
        this.default1 = default1;
    }

    public String getDefault2() {
        return default2;
    }

    public void setDefault2(String default2) {
        this.default2 = default2;
    }
}