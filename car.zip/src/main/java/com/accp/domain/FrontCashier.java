package com.accp.domain;

import java.util.Date;

public class FrontCashier {
    private Integer cashierid;

    private Float totalnum;

    private String settlementstatus;

    private String paymenttype;

    private Integer invoiceid;

    private Date cashiertime;

    private String staffid;

    private Float oncredit;

    private Integer clientid;

    private Float change;

    private Float vipbalance;

    private String default1;

    private String default2;

    public Integer getCashierid() {
        return cashierid;
    }

    public void setCashierid(Integer cashierid) {
        this.cashierid = cashierid;
    }

    public Float getTotalnum() {
        return totalnum;
    }

    public void setTotalnum(Float totalnum) {
        this.totalnum = totalnum;
    }

    public String getSettlementstatus() {
        return settlementstatus;
    }

    public void setSettlementstatus(String settlementstatus) {
        this.settlementstatus = settlementstatus;
    }

    public String getPaymenttype() {
        return paymenttype;
    }

    public void setPaymenttype(String paymenttype) {
        this.paymenttype = paymenttype;
    }

    public Integer getInvoiceid() {
        return invoiceid;
    }

    public void setInvoiceid(Integer invoiceid) {
        this.invoiceid = invoiceid;
    }

    public Date getCashiertime() {
        return cashiertime;
    }

    public void setCashiertime(Date cashiertime) {
        this.cashiertime = cashiertime;
    }

    public String getStaffid() {
        return staffid;
    }

    public void setStaffid(String staffid) {
        this.staffid = staffid;
    }

    public Float getOncredit() {
        return oncredit;
    }

    public void setOncredit(Float oncredit) {
        this.oncredit = oncredit;
    }

    public Integer getClientid() {
        return clientid;
    }

    public void setClientid(Integer clientid) {
        this.clientid = clientid;
    }

    public Float getChange() {
        return change;
    }

    public void setChange(Float change) {
        this.change = change;
    }

    public Float getVipbalance() {
        return vipbalance;
    }

    public void setVipbalance(Float vipbalance) {
        this.vipbalance = vipbalance;
    }

    public String getDefault1() {
        return default1;
    }

    public void setDefault1(String default1) {
        this.default1 = default1;
    }

    public String getDefault2() {
        return default2;
    }

    public void setDefault2(String default2) {
        this.default2 = default2;
    }
}