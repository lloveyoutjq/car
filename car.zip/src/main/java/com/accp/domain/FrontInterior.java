package com.accp.domain;

public class FrontInterior {
    private Integer interiorid;

    private String artisanname;

    private String weight;

    private String default1;

    private String default2;

    public Integer getInteriorid() {
        return interiorid;
    }

    public void setInteriorid(Integer interiorid) {
        this.interiorid = interiorid;
    }

    public String getArtisanname() {
        return artisanname;
    }

    public void setArtisanname(String artisanname) {
        this.artisanname = artisanname;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDefault1() {
        return default1;
    }

    public void setDefault1(String default1) {
        this.default1 = default1;
    }

    public String getDefault2() {
        return default2;
    }

    public void setDefault2(String default2) {
        this.default2 = default2;
    }
}