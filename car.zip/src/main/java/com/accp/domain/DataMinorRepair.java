package com.accp.domain;

public class DataMinorRepair {
    private Integer id;

    private String minorrepairname;

    private String default1;

    private String default2;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMinorrepairname() {
        return minorrepairname;
    }

    public void setMinorrepairname(String minorrepairname) {
        this.minorrepairname = minorrepairname;
    }

    public String getDefault1() {
        return default1;
    }

    public void setDefault1(String default1) {
        this.default1 = default1;
    }

    public String getDefault2() {
        return default2;
    }

    public void setDefault2(String default2) {
        this.default2 = default2;
    }
}