package com.accp.mapper;

import com.accp.domain.SystemPermissions;
import com.accp.domain.SystemPermissionsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SystemPermissionsMapper {
    int countByExample(SystemPermissionsExample example);

    int deleteByExample(SystemPermissionsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SystemPermissions record);

    int insertSelective(SystemPermissions record);

    List<SystemPermissions> selectByExample(SystemPermissionsExample example);

    SystemPermissions selectByPrimaryKey(Integer id);

    List<SystemPermissions> selectUserMenuAll(@Param("type")Integer type,@Param("uid")Integer uid);

    int updateByExampleSelective(@Param("record") SystemPermissions record, @Param("example") SystemPermissionsExample example);

    int updateByExample(@Param("record") SystemPermissions record, @Param("example") SystemPermissionsExample example);

    int updateByPrimaryKeySelective(SystemPermissions record);

    int updateByPrimaryKey(SystemPermissions record);
}