package com.accp.controller;

import com.accp.domain.ClientClientdata;
import com.accp.service.service.CustomerArchivesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/service")
public class ServiceController {
    @Autowired
    CustomerArchivesService customerArchivesService;

    @RequestMapping("addClient")
    public Map addClient(@RequestBody ClientClientdata clientClientdata){
        Map<String,Object> map = new HashMap<>();
        if(customerArchivesService.addClient(clientClientdata)>0){
            map.put("code","0");
            map.put("msg","成功");
        }else{
            map.put("code","0");
            map.put("msg","失败");
        }
        //map.put("a",clientClientdata);
        return map;
    }

    @RequestMapping("updateClient")
    public Map updateClient(@RequestBody ClientClientdata clientClientdata){
        Map<String,Object> map = new HashMap<>();
        if(customerArchivesService.updateClient(clientClientdata)>0){
            map.put("code","0");
            map.put("msg","成功");
        }else{
            map.put("code","0");
            map.put("msg","失败");
        }
        return map;
    }

    public Map select(){

        return null;
    }
}
